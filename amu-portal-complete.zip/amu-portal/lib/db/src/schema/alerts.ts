import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { farmsTable } from "./farms";
import { treatmentsTable } from "./treatments";

export const alertsTable = pgTable("alerts", {
  id: serial("id").primaryKey(),
  treatmentId: integer("treatment_id").notNull().references(() => treatmentsTable.id),
  farmId: integer("farm_id").notNull().references(() => farmsTable.id),
  type: text("type").notNull(),
  message: text("message").notNull(),
  severity: text("severity").notNull().default("warning"),
  status: text("status").notNull().default("open"),
  triggeredAt: timestamp("triggered_at").defaultNow().notNull(),
  resolvedAt: timestamp("resolved_at"),
});

export const insertAlertSchema = createInsertSchema(alertsTable).omit({ id: true, triggeredAt: true });
export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type Alert = typeof alertsTable.$inferSelect;
