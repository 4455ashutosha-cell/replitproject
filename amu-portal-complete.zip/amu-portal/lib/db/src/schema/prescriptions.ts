import { pgTable, serial, text, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { farmsTable } from "./farms";
import { animalsTable } from "./animals";
import { drugsTable } from "./drugs";

export const prescriptionsTable = pgTable("prescriptions", {
  id: serial("id").primaryKey(),
  farmId: integer("farm_id").notNull().references(() => farmsTable.id),
  animalId: integer("animal_id").notNull().references(() => animalsTable.id),
  drugId: integer("drug_id").notNull().references(() => drugsTable.id),
  vetName: text("vet_name").notNull(),
  vetLicense: text("vet_license").notNull(),
  diagnosis: text("diagnosis"),
  dosage: real("dosage").notNull(),
  unit: text("unit").notNull(),
  frequency: text("frequency").notNull(),
  durationDays: integer("duration_days").notNull(),
  issuedAt: timestamp("issued_at").defaultNow().notNull(),
  status: text("status").notNull().default("issued"),
  notes: text("notes"),
});

export const insertPrescriptionSchema = createInsertSchema(prescriptionsTable).omit({ id: true, issuedAt: true });
export type InsertPrescription = z.infer<typeof insertPrescriptionSchema>;
export type Prescription = typeof prescriptionsTable.$inferSelect;
