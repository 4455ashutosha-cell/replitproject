import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { farmsTable } from "./farms";

export const animalsTable = pgTable("animals", {
  id: serial("id").primaryKey(),
  farmId: integer("farm_id").notNull().references(() => farmsTable.id),
  species: text("species").notNull(),
  breed: text("breed"),
  identifier: text("identifier").notNull(),
  count: integer("count").notNull(),
  ageMonths: integer("age_months"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAnimalSchema = createInsertSchema(animalsTable).omit({ id: true, createdAt: true });
export type InsertAnimal = z.infer<typeof insertAnimalSchema>;
export type Animal = typeof animalsTable.$inferSelect;
