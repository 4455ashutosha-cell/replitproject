import { pgTable, serial, text, integer, real, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { farmsTable } from "./farms";
import { animalsTable } from "./animals";
import { drugsTable } from "./drugs";
import { prescriptionsTable } from "./prescriptions";

export const treatmentsTable = pgTable("treatments", {
  id: serial("id").primaryKey(),
  farmId: integer("farm_id").notNull().references(() => farmsTable.id),
  animalId: integer("animal_id").notNull().references(() => animalsTable.id),
  drugId: integer("drug_id").notNull().references(() => drugsTable.id),
  prescriptionId: integer("prescription_id").references(() => prescriptionsTable.id),
  administeredBy: text("administered_by").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  dosage: real("dosage").notNull(),
  unit: text("unit").notNull(),
  frequency: text("frequency").notNull(),
  durationDays: integer("duration_days").notNull(),
  route: text("route").notNull(),
  purpose: text("purpose").notNull(),
  notes: text("notes"),
  status: text("status").notNull().default("active"),
  withdrawalEndDate: timestamp("withdrawal_end_date").notNull(),
  mrlCompliant: boolean("mrl_compliant").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTreatmentSchema = createInsertSchema(treatmentsTable).omit({ id: true, createdAt: true });
export type InsertTreatment = z.infer<typeof insertTreatmentSchema>;
export type Treatment = typeof treatmentsTable.$inferSelect;
