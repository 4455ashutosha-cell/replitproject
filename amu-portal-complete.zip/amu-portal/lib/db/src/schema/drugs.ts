import { pgTable, serial, text, real, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const drugsTable = pgTable("drugs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  genericName: text("generic_name"),
  drugClass: text("drug_class").notNull(),
  mrlLimit: real("mrl_limit").notNull(),
  withdrawalDays: integer("withdrawal_days").notNull(),
  route: text("route").notNull(),
  unit: text("unit").notNull(),
  isRestricted: boolean("is_restricted").default(false).notNull(),
});

export const insertDrugSchema = createInsertSchema(drugsTable).omit({ id: true });
export type InsertDrug = z.infer<typeof insertDrugSchema>;
export type Drug = typeof drugsTable.$inferSelect;
