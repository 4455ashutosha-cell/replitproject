import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppLayout } from "@/components/layout/AppLayout";
import NotFound from "@/pages/not-found";

import DashboardPage from "@/pages/dashboard";
import FarmsPage from "@/pages/farms";
import DrugsPage from "@/pages/drugs";
import AnimalsPage from "@/pages/animals";
import AlertsPage from "@/pages/alerts";
import PrescriptionsPage from "@/pages/prescriptions";
import TreatmentsPage from "@/pages/treatments/index";
import NewTreatmentPage from "@/pages/treatments/new";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function Router() {
  return (
    <AppLayout>
      <Switch>
        <Route path="/" component={DashboardPage} />
        <Route path="/farms" component={FarmsPage} />
        <Route path="/drugs" component={DrugsPage} />
        <Route path="/animals" component={AnimalsPage} />
        <Route path="/alerts" component={AlertsPage} />
        <Route path="/prescriptions" component={PrescriptionsPage} />
        <Route path="/treatments" component={TreatmentsPage} />
        <Route path="/treatments/new" component={NewTreatmentPage} />
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
