import { Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider } from "@/components/ui/sidebar";
import { Activity, AlertTriangle, FileText, Home, Pill, ShieldAlert, Syringe, Tractor } from "lucide-react";
import { Link, useLocation } from "wouter";

const navigation = [
  { name: "Dashboard", href: "/", icon: Home },
  { name: "Treatments", href: "/treatments", icon: Syringe },
  { name: "Prescriptions", href: "/prescriptions", icon: FileText },
  { name: "Alerts", href: "/alerts", icon: ShieldAlert },
  { name: "Farms", href: "/farms", icon: Tractor },
  { name: "Animals", href: "/animals", icon: Activity },
  { name: "Drugs Catalog", href: "/drugs", icon: Pill },
];

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-muted/30">
        <Sidebar variant="inset">
          <SidebarContent>
            <div className="flex h-16 shrink-0 items-center px-6 border-b">
              <div className="flex items-center gap-2 font-semibold text-primary">
                <Activity className="h-6 w-6" />
                <span className="text-lg">AMU Portal</span>
              </div>
            </div>
            <SidebarGroup>
              <SidebarGroupLabel>Menu</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navigation.map((item) => {
                    const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
                    return (
                      <SidebarMenuItem key={item.name}>
                        <SidebarMenuButton asChild isActive={isActive} tooltip={item.name}>
                          <Link href={item.href} className="flex items-center gap-3">
                            <item.icon className="h-4 w-4" />
                            <span>{item.name}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    );
                  })}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>
        <main className="flex-1 overflow-auto">
          <div className="container mx-auto p-6 max-w-7xl">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
