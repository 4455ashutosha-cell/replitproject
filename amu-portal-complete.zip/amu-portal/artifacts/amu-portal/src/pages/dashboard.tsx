import { useQuery } from "@tanstack/react-query";
import { 
  useGetDashboardSummary, getGetDashboardSummaryQueryKey,
  useGetAmuTrends, getGetAmuTrendsQueryKey,
  useGetUsageBySpecies, getGetUsageBySpeciesQueryKey,
  useGetUsageByDrugClass, getGetUsageByDrugClassQueryKey,
  useGetRecentActivity, getGetRecentActivityQueryKey
} from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { format } from "date-fns";
import { Activity, AlertTriangle, Building2, Pill, ShieldAlert, Syringe, FileText, CheckCircle2 } from "lucide-react";

export default function DashboardPage() {
  const { data: summary } = useGetDashboardSummary({ query: { queryKey: getGetDashboardSummaryQueryKey() } });
  const { data: trends } = useGetAmuTrends({ query: { queryKey: getGetAmuTrendsQueryKey() } });
  const { data: speciesUsage } = useGetUsageBySpecies({ query: { queryKey: getGetUsageBySpeciesQueryKey() } });
  const { data: classUsage } = useGetUsageByDrugClass({ query: { queryKey: getGetUsageByDrugClassQueryKey() } });
  const { data: activity } = useGetRecentActivity({ query: { queryKey: getGetRecentActivityQueryKey() } });

  const PIE_COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))'];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">Control Room</h1>
        <p className="text-muted-foreground">National Antimicrobial Usage & Monitoring Overview</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-t-4 border-t-blue-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Treatments</CardTitle>
            <Syringe className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summary?.activeTreatments || 0}</div>
            <p className="text-xs text-muted-foreground">
              Across {summary?.totalFarms || 0} registered farms
            </p>
          </CardContent>
        </Card>
        
        <Card className="border-t-4 border-t-red-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Critical Alerts</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{summary?.criticalAlerts || 0}</div>
            <p className="text-xs text-muted-foreground">
              {summary?.openAlerts || 0} total open alerts requiring action
            </p>
          </CardContent>
        </Card>

        <Card className="border-t-4 border-t-green-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">MRL Compliance</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{summary?.mrlCompliantPct || 100}%</div>
            <p className="text-xs text-muted-foreground">
              Of {summary?.treatmentsThisMonth || 0} treatments this month
            </p>
          </CardContent>
        </Card>

        <Card className="border-t-4 border-t-slate-500">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monitored Animals</CardTitle>
            <Activity className="h-4 w-4 text-slate-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summary?.totalAnimals || 0}</div>
            <p className="text-xs text-muted-foreground">
              In active registry
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Usage Trends & Alerts</CardTitle>
            <CardDescription>Monthly AMU treatment volume vs triggered alerts</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trends || []}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="month" axisLine={false} tickLine={false} />
                <YAxis yAxisId="left" axisLine={false} tickLine={false} />
                <YAxis yAxisId="right" orientation="right" axisLine={false} tickLine={false} />
                <Tooltip />
                <Line yAxisId="left" type="monotone" dataKey="treatmentCount" name="Treatments" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
                <Line yAxisId="right" type="monotone" dataKey="alertCount" name="Alerts" stroke="hsl(var(--destructive))" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest system events and monitoring logs</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {activity?.map((item) => (
                <div key={item.id} className="flex items-start gap-4 text-sm">
                  <div className="mt-0.5 rounded-full p-1 bg-slate-100 dark:bg-slate-800">
                    {item.type === 'treatment' ? <Syringe className="h-4 w-4 text-blue-500" /> :
                     item.type === 'alert' ? <ShieldAlert className="h-4 w-4 text-red-500" /> :
                     item.type === 'prescription' ? <FileText className="h-4 w-4 text-green-500" /> :
                     <Activity className="h-4 w-4 text-slate-500" />}
                  </div>
                  <div className="flex-1 space-y-1">
                    <p className="font-medium leading-none">{item.description}</p>
                    <div className="flex items-center text-xs text-muted-foreground gap-2">
                      <span>{format(new Date(item.timestamp), "MMM d, HH:mm")}</span>
                      {item.farmName && (
                        <>
                          <span>•</span>
                          <span>{item.farmName}</span>
                        </>
                      )}
                    </div>
                  </div>
                  {item.severity === 'critical' && (
                    <Badge variant="destructive" className="text-[10px]">Critical</Badge>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Usage by Drug Class</CardTitle>
          </CardHeader>
          <CardContent className="h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={classUsage || []} layout="vertical" margin={{ left: 50 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" hide />
                <YAxis dataKey="drugClass" type="category" axisLine={false} tickLine={false} />
                <Tooltip />
                <Bar dataKey="count" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Treatments by Species</CardTitle>
          </CardHeader>
          <CardContent className="h-[250px] flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={speciesUsage || []}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="count"
                  nameKey="species"
                  label
                >
                  {(speciesUsage || []).map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
