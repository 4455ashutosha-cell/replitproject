import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQueryClient } from "@tanstack/react-query";
import { 
  useListPrescriptions, useCreatePrescription, getListPrescriptionsQueryKey,
  useListFarms, getListFarmsQueryKey,
  useListAnimals, getListAnimalsQueryKey,
  useListDrugs, getListDrugsQueryKey
} from "@workspace/api-client-react";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { Plus } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  farmId: z.coerce.number().min(1, "Farm is required"),
  animalId: z.coerce.number().min(1, "Animal group is required"),
  drugId: z.coerce.number().min(1, "Drug is required"),
  vetName: z.string().min(1, "Vet name is required"),
  vetLicense: z.string().min(1, "Vet license is required"),
  diagnosis: z.string().optional(),
  dosage: z.coerce.number().min(0.1),
  unit: z.string().min(1),
  frequency: z.string().min(1),
  durationDays: z.coerce.number().min(1),
  notes: z.string().optional(),
});

export default function PrescriptionsPage() {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: prescriptions, isLoading } = useListPrescriptions({ query: { queryKey: getListPrescriptionsQueryKey() } });
  const { data: farms } = useListFarms({ query: { queryKey: getListFarmsQueryKey() } });
  const { data: animals } = useListAnimals({ query: { queryKey: getListAnimalsQueryKey() } });
  const { data: drugs } = useListDrugs({ query: { queryKey: getListDrugsQueryKey() } });
  
  const createPrescription = useCreatePrescription();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      farmId: 0,
      animalId: 0,
      drugId: 0,
      vetName: "",
      vetLicense: "",
      diagnosis: "",
      dosage: 0,
      unit: "ml",
      frequency: "Once daily",
      durationDays: 1,
      notes: "",
    },
  });

  const selectedFarmId = form.watch("farmId");
  const filteredAnimals = animals?.filter(a => a.farmId === selectedFarmId) || [];

  function onSubmit(values: z.infer<typeof formSchema>) {
    createPrescription.mutate({ data: values }, {
      onSuccess: () => {
        toast({ title: "Prescription issued successfully" });
        queryClient.invalidateQueries({ queryKey: getListPrescriptionsQueryKey() });
        setOpen(false);
        form.reset();
      },
      onError: () => {
        toast({ title: "Error issuing prescription", variant: "destructive" });
      }
    });
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Veterinary Prescriptions</h1>
          <p className="text-muted-foreground">Authorized treatments and required vet approvals.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="mr-2 h-4 w-4" /> Issue Prescription</Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Issue New Prescription</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="farmId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Farm</FormLabel>
                        <Select onValueChange={(val) => { field.onChange(val); form.setValue('animalId', 0); }} value={field.value ? String(field.value) : ""}>
                          <FormControl>
                            <SelectTrigger><SelectValue placeholder="Select farm" /></SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {farms?.map((farm) => (
                              <SelectItem key={farm.id} value={String(farm.id)}>{farm.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="animalId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Animal / Herd</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value ? String(field.value) : ""} disabled={!selectedFarmId}>
                          <FormControl>
                            <SelectTrigger><SelectValue placeholder="Select subject" /></SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {filteredAnimals.map((animal) => (
                              <SelectItem key={animal.id} value={String(animal.id)}>{animal.identifier}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="vetName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Veterinarian Name</FormLabel>
                        <FormControl><Input {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="vetLicense"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Vet License #</FormLabel>
                        <FormControl><Input {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="drugId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Drug</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value ? String(field.value) : ""}>
                          <FormControl>
                            <SelectTrigger><SelectValue placeholder="Select drug" /></SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {drugs?.map((drug) => (
                              <SelectItem key={drug.id} value={String(drug.id)}>
                                {drug.name} {drug.isRestricted ? '(Restricted)' : ''}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="diagnosis"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Diagnosis</FormLabel>
                        <FormControl><Input {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-4 gap-4 p-4 rounded-md border bg-muted/50">
                  <FormField
                    control={form.control}
                    name="dosage"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Dosage</FormLabel>
                        <FormControl><Input type="number" step="0.1" {...field} /></FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="unit"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Unit</FormLabel>
                        <FormControl><Input {...field} /></FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="frequency"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Freq.</FormLabel>
                        <FormControl><Input {...field} /></FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="durationDays"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Days</FormLabel>
                        <FormControl><Input type="number" {...field} /></FormControl>
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Notes</FormLabel>
                      <FormControl><Textarea {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full" disabled={createPrescription.isPending}>
                  {createPrescription.isPending ? "Issuing..." : "Issue Prescription"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-md border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Rx ID</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Subject</TableHead>
              <TableHead>Drug</TableHead>
              <TableHead>Regimen</TableHead>
              <TableHead>Veterinarian</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center h-24">Loading prescriptions...</TableCell>
              </TableRow>
            ) : prescriptions?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center h-24 text-muted-foreground">No prescriptions found.</TableCell>
              </TableRow>
            ) : (
              prescriptions?.map((rx) => (
                <TableRow key={rx.id}>
                  <TableCell className="font-mono text-xs text-muted-foreground">RX-{rx.id.toString().padStart(4, '0')}</TableCell>
                  <TableCell>{format(new Date(rx.issuedAt), "MMM d, yyyy")}</TableCell>
                  <TableCell>
                    <div className="font-medium">{rx.animalIdentifier}</div>
                    <div className="text-xs text-muted-foreground">{rx.farmName}</div>
                  </TableCell>
                  <TableCell className="font-medium text-primary">{rx.drugName}</TableCell>
                  <TableCell className="text-xs">
                    {rx.dosage}{rx.unit} • {rx.frequency} • {rx.durationDays}d
                  </TableCell>
                  <TableCell>
                    <div>{rx.vetName}</div>
                    <div className="text-xs text-muted-foreground">{rx.vetLicense}</div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={rx.status === 'Completed' ? 'secondary' : 'default'} className={
                      rx.status === 'Issued' ? 'bg-blue-100 text-blue-800' :
                      rx.status === 'Dispensed' ? 'bg-orange-100 text-orange-800' :
                      'bg-green-100 text-green-800'
                    }>
                      {rx.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
