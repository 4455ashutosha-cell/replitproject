import { useQueryClient } from "@tanstack/react-query";
import { 
  useListAlerts, getListAlertsQueryKey,
  useResolveAlert
} from "@workspace/api-client-react";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Clock, ShieldAlert, CheckCircle2 } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

export default function AlertsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: alerts, isLoading } = useListAlerts({ query: { queryKey: getListAlertsQueryKey() } });
  const resolveAlert = useResolveAlert();

  const handleResolve = (id: number) => {
    resolveAlert.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Alert marked as resolved" });
        queryClient.invalidateQueries({ queryKey: getListAlertsQueryKey() });
      },
      onError: () => {
        toast({ title: "Error resolving alert", variant: "destructive" });
      }
    });
  };

  const getSeverityColor = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'critical': return 'border-red-500 bg-red-50 text-red-900 dark:bg-red-900/20 dark:text-red-200';
      case 'warning': return 'border-orange-500 bg-orange-50 text-orange-900 dark:bg-orange-900/20 dark:text-orange-200';
      default: return 'border-blue-500 bg-blue-50 text-blue-900 dark:bg-blue-900/20 dark:text-blue-200';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'critical': return <ShieldAlert className="h-5 w-5 text-red-600" />;
      case 'warning': return <AlertTriangle className="h-5 w-5 text-orange-600" />;
      default: return <Clock className="h-5 w-5 text-blue-600" />;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Compliance Alerts</h1>
        <p className="text-muted-foreground">Actionable warnings for MRL breaches and withdrawal period violations.</p>
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Loading alerts...</div>
      ) : alerts?.length === 0 ? (
        <div className="text-center py-12 flex flex-col items-center">
          <CheckCircle2 className="h-12 w-12 text-green-500 mb-4" />
          <h3 className="text-lg font-medium">All Clear</h3>
          <p className="text-muted-foreground">No active compliance alerts at this time.</p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {alerts?.map((alert) => (
            <Card key={alert.id} className={`border-l-4 ${getSeverityColor(alert.severity).split(' ')[0]}`}>
              <CardHeader className="pb-2 flex flex-row items-start justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    {getSeverityIcon(alert.severity)}
                    <span className="font-semibold capitalize">{alert.severity}</span>
                  </div>
                  <Badge variant="outline" className="uppercase text-[10px] tracking-wider">{alert.type.replace('_', ' ')}</Badge>
                </div>
                {alert.status === 'resolved' && (
                  <Badge variant="secondary" className="bg-green-100 text-green-800">Resolved</Badge>
                )}
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm font-medium leading-tight">{alert.message}</p>
                <div className="text-xs space-y-1 text-muted-foreground">
                  {alert.farmName && <div><span className="font-medium">Farm:</span> {alert.farmName}</div>}
                  {alert.animalIdentifier && <div><span className="font-medium">Subject:</span> {alert.animalIdentifier}</div>}
                  {alert.drugName && <div><span className="font-medium">Drug:</span> {alert.drugName}</div>}
                  <div><span className="font-medium">Triggered:</span> {format(new Date(alert.triggeredAt), "MMM d, yyyy HH:mm")}</div>
                </div>
              </CardContent>
              {alert.status !== 'resolved' && (
                <CardFooter className="pt-0">
                  <Button 
                    variant="outline" 
                    className="w-full" 
                    onClick={() => handleResolve(alert.id)}
                    disabled={resolveAlert.isPending}
                  >
                    Mark as Resolved
                  </Button>
                </CardFooter>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
