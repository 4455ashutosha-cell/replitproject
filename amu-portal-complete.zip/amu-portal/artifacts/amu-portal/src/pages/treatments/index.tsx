import { useQuery } from "@tanstack/react-query";
import { 
  useListTreatments, getListTreatmentsQueryKey
} from "@workspace/api-client-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Plus, Syringe, AlertTriangle, ShieldCheck } from "lucide-react";
import { format, differenceInDays } from "date-fns";

export default function TreatmentsPage() {
  const { data: treatments, isLoading } = useListTreatments({ query: { queryKey: getListTreatmentsQueryKey() } });

  const getStatusBadge = (status: string) => {
    switch(status.toLowerCase()) {
      case 'active': return <Badge className="bg-blue-500 hover:bg-blue-600">Active</Badge>;
      case 'completed': return <Badge variant="secondary" className="bg-slate-200">Completed</Badge>;
      case 'withdrawal': return <Badge className="bg-orange-500 hover:bg-orange-600">Withdrawal</Badge>;
      default: return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Treatment Logs</h1>
          <p className="text-muted-foreground">Comprehensive record of all antimicrobial administrations.</p>
        </div>
        <Link href="/treatments/new" className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2">
          <Plus className="mr-2 h-4 w-4" /> Log Treatment
        </Link>
      </div>

      <div className="rounded-md border bg-card shadow-sm">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Farm & Subject</TableHead>
              <TableHead>Drug Administered</TableHead>
              <TableHead>Regimen</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Compliance</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center h-32">Loading treatments...</TableCell>
              </TableRow>
            ) : treatments?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center h-32 text-muted-foreground">No treatments logged yet.</TableCell>
              </TableRow>
            ) : (
              treatments?.map((t) => {
                const isWithdrawal = t.status === 'Withdrawal';
                const daysLeft = isWithdrawal ? differenceInDays(new Date(t.withdrawalEndDate), new Date()) : 0;
                
                return (
                  <TableRow key={t.id}>
                    <TableCell>
                      <div className="font-medium">{format(new Date(t.startDate), "MMM d, yyyy")}</div>
                      {t.endDate && <div className="text-xs text-muted-foreground">to {format(new Date(t.endDate), "MMM d")}</div>}
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{t.animalIdentifier}</div>
                      <div className="text-xs text-muted-foreground">{t.farmName} • {t.animalSpecies}</div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Syringe className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{t.drugName}</span>
                      </div>
                      <div className="text-xs text-muted-foreground ml-6">{t.drugClass}</div>
                    </TableCell>
                    <TableCell className="text-sm">
                      <div>{t.dosage}{t.unit} • {t.route}</div>
                      <div className="text-muted-foreground">{t.frequency} • {t.durationDays} days</div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        {getStatusBadge(t.status)}
                        {isWithdrawal && daysLeft > 0 && (
                          <div className="text-xs font-medium text-orange-600 flex items-center gap-1 mt-1">
                            <AlertTriangle className="h-3 w-3" /> {daysLeft}d left
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {t.mrlCompliant ? (
                        <div className="flex items-center text-green-600 gap-1 text-sm font-medium">
                          <ShieldCheck className="h-4 w-4" /> Compliant
                        </div>
                      ) : (
                        <div className="flex items-center text-red-600 gap-1 text-sm font-medium">
                          <AlertTriangle className="h-4 w-4" /> Flagged
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
