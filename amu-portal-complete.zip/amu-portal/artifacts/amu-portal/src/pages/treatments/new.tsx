import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { 
  useCreateTreatment, getListTreatmentsQueryKey,
  useListFarms, getListFarmsQueryKey,
  useListAnimals, getListAnimalsQueryKey,
  useListDrugs, getListDrugsQueryKey,
  useListPrescriptions, getListPrescriptionsQueryKey
} from "@workspace/api-client-react";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Link as LinkIcon } from "lucide-react";
import { Link } from "wouter";

const formSchema = z.object({
  farmId: z.coerce.number().min(1, "Farm is required"),
  animalId: z.coerce.number().min(1, "Animal group is required"),
  drugId: z.coerce.number().min(1, "Drug is required"),
  prescriptionId: z.coerce.number().optional(),
  administeredBy: z.string().min(1, "Administrator name is required"),
  startDate: z.string().min(1, "Start date is required"),
  dosage: z.coerce.number().min(0.1, "Dosage is required"),
  unit: z.string().min(1),
  frequency: z.string().min(1),
  durationDays: z.coerce.number().min(1),
  route: z.string().min(1),
  purpose: z.string().min(1, "Treatment purpose is required"),
  notes: z.string().optional(),
});

export default function NewTreatmentPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: farms } = useListFarms({ query: { queryKey: getListFarmsQueryKey() } });
  const { data: animals } = useListAnimals({ query: { queryKey: getListAnimalsQueryKey() } });
  const { data: drugs } = useListDrugs({ query: { queryKey: getListDrugsQueryKey() } });
  const { data: prescriptions } = useListPrescriptions({ query: { queryKey: getListPrescriptionsQueryKey() } });
  
  const createTreatment = useCreateTreatment();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      farmId: 0,
      animalId: 0,
      drugId: 0,
      prescriptionId: undefined,
      administeredBy: "",
      startDate: new Date().toISOString().split('T')[0],
      dosage: 0,
      unit: "ml",
      frequency: "Once daily",
      durationDays: 1,
      route: "IM",
      purpose: "Prophylactic",
      notes: "",
    },
  });

  const selectedFarmId = form.watch("farmId");
  const filteredAnimals = animals?.filter(a => a.farmId === selectedFarmId) || [];
  
  // Auto-fill from prescription
  const handlePrescriptionSelect = (rxId: string) => {
    if (!rxId || rxId === "none") {
      form.setValue("prescriptionId", undefined);
      return;
    }
    
    const rx = prescriptions?.find(p => p.id === Number(rxId));
    if (rx) {
      form.setValue("prescriptionId", rx.id);
      form.setValue("farmId", rx.farmId);
      form.setValue("animalId", rx.animalId);
      form.setValue("drugId", rx.drugId);
      if (rx.dosage) form.setValue("dosage", rx.dosage);
      if (rx.unit) form.setValue("unit", rx.unit);
      if (rx.frequency) form.setValue("frequency", rx.frequency);
      if (rx.durationDays) form.setValue("durationDays", rx.durationDays);
      form.setValue("purpose", rx.diagnosis || "Therapeutic");
    }
  };

  function onSubmit(values: z.infer<typeof formSchema>) {
    createTreatment.mutate({ data: values }, {
      onSuccess: () => {
        toast({ title: "Treatment logged successfully" });
        queryClient.invalidateQueries({ queryKey: getListTreatmentsQueryKey() });
        setLocation("/treatments");
      },
      onError: () => {
        toast({ title: "Error logging treatment", variant: "destructive" });
      }
    });
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-12">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" asChild className="h-8 w-8">
          <Link href="/treatments"><ArrowLeft className="h-4 w-4" /></Link>
        </Button>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Log Antimicrobial Treatment</h1>
          <p className="text-muted-foreground">Record a new administration event into the compliance registry.</p>
        </div>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card>
            <CardHeader className="bg-muted/30 pb-4 border-b">
              <CardTitle className="text-lg flex items-center gap-2">
                <LinkIcon className="h-4 w-4 text-muted-foreground" />
                Link Prescription (Optional)
              </CardTitle>
              <CardDescription>Selecting a prescription will auto-fill the required fields below.</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <FormField
                control={form.control}
                name="prescriptionId"
                render={({ field }) => (
                  <FormItem>
                    <Select 
                      onValueChange={handlePrescriptionSelect} 
                      value={field.value ? String(field.value) : "none"}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select an active prescription..." />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none">No prescription (Over the counter / Standing order)</SelectItem>
                        {prescriptions?.filter(p => p.status !== 'Completed').map((rx) => (
                          <SelectItem key={rx.id} value={String(rx.id)}>
                            RX-{rx.id.toString().padStart(4, '0')} - {rx.drugName} for {rx.animalIdentifier} (by {rx.vetName})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">Location & Subject</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="farmId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Farm Facility</FormLabel>
                      <Select onValueChange={(val) => { field.onChange(val); form.setValue('animalId', 0); }} value={field.value ? String(field.value) : ""}>
                        <FormControl>
                          <SelectTrigger><SelectValue placeholder="Select farm" /></SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {farms?.map((farm) => (
                            <SelectItem key={farm.id} value={String(farm.id)}>{farm.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="animalId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Animal / Herd Identifier</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value ? String(field.value) : ""} disabled={!selectedFarmId}>
                        <FormControl>
                          <SelectTrigger><SelectValue placeholder="Select subject" /></SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {filteredAnimals.map((animal) => (
                            <SelectItem key={animal.id} value={String(animal.id)}>{animal.identifier}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">Administration Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="administeredBy"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Administered By</FormLabel>
                      <FormControl><Input {...field} placeholder="Name of person administering" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Start Date</FormLabel>
                      <FormControl><Input type="date" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="purpose"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Treatment Purpose</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Therapeutic">Therapeutic (Treating active illness)</SelectItem>
                          <SelectItem value="Prophylactic">Prophylactic (Disease prevention)</SelectItem>
                          <SelectItem value="Metaphylactic">Metaphylactic (Treating group after one illness)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="text-lg">Drug Regimen</CardTitle>
              <CardDescription>Specifying the exact dosage is critical for MRL compliance calculations.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="drugId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Antimicrobial Drug</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value ? String(field.value) : ""}>
                        <FormControl>
                          <SelectTrigger><SelectValue placeholder="Select from catalog" /></SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {drugs?.map((drug) => (
                            <SelectItem key={drug.id} value={String(drug.id)}>
                              {drug.name} ({drug.drugClass})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="route"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Administration Route</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="IM">Intramuscular (IM)</SelectItem>
                          <SelectItem value="IV">Intravenous (IV)</SelectItem>
                          <SelectItem value="SC">Subcutaneous (SC)</SelectItem>
                          <SelectItem value="Oral">Oral (Feed/Water)</SelectItem>
                          <SelectItem value="Topical">Topical</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-muted/30 rounded-lg border">
                <FormField
                  control={form.control}
                  name="dosage"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Dosage</FormLabel>
                      <FormControl><Input type="number" step="0.1" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="unit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Unit</FormLabel>
                      <FormControl><Input {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="frequency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Frequency</FormLabel>
                      <FormControl><Input {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="durationDays"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Duration (Days)</FormLabel>
                      <FormControl><Input type="number" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Clinical Notes</FormLabel>
                    <FormControl><Textarea placeholder="Observations, adverse reactions, etc." className="min-h-[100px]" {...field} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <div className="flex justify-end gap-4">
            <Button variant="outline" asChild>
              <Link href="/treatments">Cancel</Link>
            </Button>
            <Button type="submit" size="lg" disabled={createTreatment.isPending}>
              {createTreatment.isPending ? "Recording..." : "Record Treatment"}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
