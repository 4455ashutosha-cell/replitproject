import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQueryClient } from "@tanstack/react-query";
import { 
  useListAnimals, useCreateAnimal, getListAnimalsQueryKey,
  useListFarms, getListFarmsQueryKey
} from "@workspace/api-client-react";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { Plus } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  farmId: z.coerce.number().min(1, "Farm is required"),
  species: z.string().min(1, "Species is required"),
  breed: z.string().optional(),
  identifier: z.string().min(1, "Group/Herd identifier is required"),
  count: z.coerce.number().min(1, "Count must be at least 1"),
  ageMonths: z.coerce.number().optional(),
});

export default function AnimalsPage() {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: animals, isLoading } = useListAnimals({ query: { queryKey: getListAnimalsQueryKey() } });
  const { data: farms } = useListFarms({ query: { queryKey: getListFarmsQueryKey() } });
  const createAnimal = useCreateAnimal();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      farmId: 0,
      species: "Bovine",
      breed: "",
      identifier: "",
      count: 1,
      ageMonths: 0,
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    createAnimal.mutate({ data: values }, {
      onSuccess: () => {
        toast({ title: "Animal group registered successfully" });
        queryClient.invalidateQueries({ queryKey: getListAnimalsQueryKey() });
        setOpen(false);
        form.reset();
      },
      onError: () => {
        toast({ title: "Error registering animals", variant: "destructive" });
      }
    });
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Animal & Herd Registry</h1>
          <p className="text-muted-foreground">Manage animal populations for tracking and MRL monitoring.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="mr-2 h-4 w-4" /> Add Animal Group</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Register Animal Group</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="farmId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Farm</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value ? String(field.value) : ""}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a farm" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {farms?.map((farm) => (
                            <SelectItem key={farm.id} value={String(farm.id)}>{farm.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="species"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Species</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select species" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Bovine">Bovine (Cattle)</SelectItem>
                            <SelectItem value="Porcine">Porcine (Pigs)</SelectItem>
                            <SelectItem value="Ovine">Ovine (Sheep)</SelectItem>
                            <SelectItem value="Avian">Avian (Poultry)</SelectItem>
                            <SelectItem value="Caprine">Caprine (Goats)</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="breed"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Breed (Optional)</FormLabel>
                        <FormControl><Input {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="identifier"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Herd/Group Identifier</FormLabel>
                      <FormControl><Input {...field} placeholder="e.g. Barn A, Batch 42" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="count"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Head Count</FormLabel>
                        <FormControl><Input type="number" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="ageMonths"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Avg Age (Months)</FormLabel>
                        <FormControl><Input type="number" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <Button type="submit" className="w-full" disabled={createAnimal.isPending}>
                  {createAnimal.isPending ? "Saving..." : "Register Group"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-md border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Identifier</TableHead>
              <TableHead>Farm</TableHead>
              <TableHead>Species</TableHead>
              <TableHead>Head Count</TableHead>
              <TableHead>Registered</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center h-24">Loading registry...</TableCell>
              </TableRow>
            ) : animals?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center h-24 text-muted-foreground">No animals registered yet.</TableCell>
              </TableRow>
            ) : (
              animals?.map((animal) => (
                <TableRow key={animal.id}>
                  <TableCell className="font-medium">{animal.identifier}</TableCell>
                  <TableCell>{animal.farmName}</TableCell>
                  <TableCell>
                    <div>{animal.species}</div>
                    {animal.breed && <div className="text-xs text-muted-foreground">{animal.breed}</div>}
                  </TableCell>
                  <TableCell>{animal.count}</TableCell>
                  <TableCell>{format(new Date(animal.createdAt), "MMM d, yyyy")}</TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
