import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQueryClient } from "@tanstack/react-query";
import { useListDrugs, useCreateDrug, getListDrugsQueryKey } from "@workspace/api-client-react";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { useState } from "react";
import { Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  name: z.string().min(1, "Name is required"),
  genericName: z.string().optional(),
  drugClass: z.string().min(1, "Class is required"),
  mrlLimit: z.coerce.number().min(0),
  withdrawalDays: z.coerce.number().min(0),
  route: z.string().min(1, "Route is required"),
  unit: z.string().min(1, "Unit is required"),
  isRestricted: z.boolean().default(false),
});

export default function DrugsPage() {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: drugs, isLoading } = useListDrugs({ query: { queryKey: getListDrugsQueryKey() } });
  const createDrug = useCreateDrug();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      genericName: "",
      drugClass: "",
      mrlLimit: 0,
      withdrawalDays: 0,
      route: "IM",
      unit: "ml",
      isRestricted: false,
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    createDrug.mutate({ data: values }, {
      onSuccess: () => {
        toast({ title: "Drug catalog updated" });
        queryClient.invalidateQueries({ queryKey: getListDrugsQueryKey() });
        setOpen(false);
        form.reset();
      },
      onError: () => {
        toast({ title: "Error adding drug", variant: "destructive" });
      }
    });
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Drug Catalog</h1>
          <p className="text-muted-foreground">Manage antimicrobial definitions, MRL limits, and withdrawal periods.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="mr-2 h-4 w-4" /> Add Drug</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Antimicrobial Drug</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Brand Name</FormLabel>
                        <FormControl><Input {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="genericName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Generic Name</FormLabel>
                        <FormControl><Input {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="drugClass"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Class</FormLabel>
                        <FormControl><Input {...field} placeholder="e.g. Tetracyclines" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="mrlLimit"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>MRL Limit (µg/kg)</FormLabel>
                        <FormControl><Input type="number" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="withdrawalDays"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Withdrawal Period (Days)</FormLabel>
                        <FormControl><Input type="number" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <FormField
                      control={form.control}
                      name="route"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Route</FormLabel>
                          <FormControl><Input {...field} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="unit"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Unit</FormLabel>
                          <FormControl><Input {...field} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                <FormField
                  control={form.control}
                  name="isRestricted"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>Restricted Use</FormLabel>
                        <p className="text-sm text-muted-foreground">Requires veterinary authorization.</p>
                      </div>
                    </FormItem>
                  )}
                />
                <Button type="submit" className="w-full" disabled={createDrug.isPending}>
                  {createDrug.isPending ? "Saving..." : "Save Drug"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-md border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Drug Name</TableHead>
              <TableHead>Class</TableHead>
              <TableHead>MRL Limit</TableHead>
              <TableHead>Withdrawal (Days)</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center h-24">Loading catalog...</TableCell>
              </TableRow>
            ) : drugs?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center h-24 text-muted-foreground">No drugs listed yet.</TableCell>
              </TableRow>
            ) : (
              drugs?.map((drug) => (
                <TableRow key={drug.id}>
                  <TableCell>
                    <div className="font-medium">{drug.name}</div>
                    {drug.genericName && <div className="text-xs text-muted-foreground">{drug.genericName}</div>}
                  </TableCell>
                  <TableCell>{drug.drugClass}</TableCell>
                  <TableCell>{drug.mrlLimit} µg/kg</TableCell>
                  <TableCell>{drug.withdrawalDays} days</TableCell>
                  <TableCell>
                    {drug.isRestricted ? (
                      <Badge variant="destructive" className="bg-orange-100 text-orange-800 hover:bg-orange-100 border-orange-200">Restricted</Badge>
                    ) : (
                      <Badge variant="secondary" className="bg-green-100 text-green-800 hover:bg-green-100 border-green-200">Standard</Badge>
                    )}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
