import { Router } from "express";
import { db } from "@workspace/db";
import { prescriptionsTable, farmsTable, animalsTable, drugsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { CreatePrescriptionBody, UpdatePrescriptionBody } from "@workspace/api-zod";

const router = Router();

const withJoins = () =>
  db.select({
    id: prescriptionsTable.id,
    farmId: prescriptionsTable.farmId,
    farmName: farmsTable.name,
    animalId: prescriptionsTable.animalId,
    animalIdentifier: animalsTable.identifier,
    drugId: prescriptionsTable.drugId,
    drugName: drugsTable.name,
    vetName: prescriptionsTable.vetName,
    vetLicense: prescriptionsTable.vetLicense,
    diagnosis: prescriptionsTable.diagnosis,
    dosage: prescriptionsTable.dosage,
    unit: prescriptionsTable.unit,
    frequency: prescriptionsTable.frequency,
    durationDays: prescriptionsTable.durationDays,
    issuedAt: prescriptionsTable.issuedAt,
    status: prescriptionsTable.status,
    notes: prescriptionsTable.notes,
  })
    .from(prescriptionsTable)
    .leftJoin(farmsTable, eq(prescriptionsTable.farmId, farmsTable.id))
    .leftJoin(animalsTable, eq(prescriptionsTable.animalId, animalsTable.id))
    .leftJoin(drugsTable, eq(prescriptionsTable.drugId, drugsTable.id));

router.get("/prescriptions", async (req, res) => {
  const rows = await withJoins().orderBy(prescriptionsTable.issuedAt);
  res.json(rows.map(r => ({ ...r, issuedAt: r.issuedAt.toISOString() })));
});

router.post("/prescriptions", async (req, res) => {
  const parsed = CreatePrescriptionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }
  const [rx] = await db.insert(prescriptionsTable).values(parsed.data).returning();
  const rows = await withJoins().where(eq(prescriptionsTable.id, rx.id));
  res.status(201).json({ ...rows[0], issuedAt: rows[0].issuedAt.toISOString() });
});

router.get("/prescriptions/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const rows = await withJoins().where(eq(prescriptionsTable.id, id));
  if (!rows[0]) { res.status(404).json({ error: "Not found" }); return; }
  res.json({ ...rows[0], issuedAt: rows[0].issuedAt.toISOString() });
});

router.patch("/prescriptions/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const parsed = UpdatePrescriptionBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid input" }); return; }
  await db.update(prescriptionsTable).set(parsed.data).where(eq(prescriptionsTable.id, id));
  const rows = await withJoins().where(eq(prescriptionsTable.id, id));
  if (!rows[0]) { res.status(404).json({ error: "Not found" }); return; }
  res.json({ ...rows[0], issuedAt: rows[0].issuedAt.toISOString() });
});

export default router;
