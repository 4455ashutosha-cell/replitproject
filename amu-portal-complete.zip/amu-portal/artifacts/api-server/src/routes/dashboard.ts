import { Router } from "express";
import { db } from "@workspace/db";
import { treatmentsTable, farmsTable, animalsTable, drugsTable, alertsTable } from "@workspace/db";
import { eq, count, sql } from "drizzle-orm";

const router = Router();

router.get("/dashboard/summary", async (req, res) => {
  const [{ farmCount }] = await db.select({ farmCount: count() }).from(farmsTable);
  const [{ animalCount }] = await db.select({ animalCount: count() }).from(animalsTable);
  const [{ treatmentCount }] = await db.select({ treatmentCount: count() }).from(treatmentsTable);
  const [{ activeCount }] = await db
    .select({ activeCount: count() })
    .from(treatmentsTable)
    .where(eq(treatmentsTable.status, "active"));
  const [{ openAlerts }] = await db
    .select({ openAlerts: count() })
    .from(alertsTable)
    .where(eq(alertsTable.status, "open"));
  const [{ criticalAlerts }] = await db
    .select({ criticalAlerts: count() })
    .from(alertsTable)
    .where(sql`${alertsTable.status} = 'open' AND ${alertsTable.severity} = 'critical'`);

  const compliant = await db
    .select({ mrlCompliant: treatmentsTable.mrlCompliant })
    .from(treatmentsTable);
  const mrlCompliantPct = compliant.length === 0
    ? 100
    : Math.round((compliant.filter(t => t.mrlCompliant).length / compliant.length) * 100);

  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const [{ thisMonth }] = await db
    .select({ thisMonth: count() })
    .from(treatmentsTable)
    .where(sql`${treatmentsTable.createdAt} >= ${startOfMonth}`);

  res.json({
    totalFarms: farmCount,
    totalAnimals: animalCount,
    totalTreatments: treatmentCount,
    activeTreatments: activeCount,
    openAlerts,
    criticalAlerts,
    mrlCompliantPct,
    treatmentsThisMonth: thisMonth,
  });
});

router.get("/dashboard/trends", async (req, res) => {
  const treatments = await db
    .select({ createdAt: treatmentsTable.createdAt })
    .from(treatmentsTable);
  const alerts = await db
    .select({ triggeredAt: alertsTable.triggeredAt })
    .from(alertsTable);

  const monthMap: Record<string, { treatmentCount: number; alertCount: number }> = {};
  const getMonthKey = (d: Date) => {
    const y = d.getFullYear();
    const m = (d.getMonth() + 1).toString().padStart(2, "0");
    return `${y}-${m}`;
  };

  for (const t of treatments) {
    const key = getMonthKey(t.createdAt);
    monthMap[key] = monthMap[key] ?? { treatmentCount: 0, alertCount: 0 };
    monthMap[key].treatmentCount++;
  }
  for (const a of alerts) {
    const key = getMonthKey(a.triggeredAt);
    monthMap[key] = monthMap[key] ?? { treatmentCount: 0, alertCount: 0 };
    monthMap[key].alertCount++;
  }

  const sorted = Object.entries(monthMap)
    .sort(([a], [b]) => a.localeCompare(b))
    .slice(-12)
    .map(([month, data]) => ({ month, ...data }));

  res.json(sorted);
});

router.get("/dashboard/by-species", async (req, res) => {
  const rows = await db
    .select({ species: animalsTable.species, treatmentId: treatmentsTable.id })
    .from(treatmentsTable)
    .leftJoin(animalsTable, eq(treatmentsTable.animalId, animalsTable.id));

  const speciesMap: Record<string, number> = {};
  for (const r of rows) {
    const sp = r.species ?? "Unknown";
    speciesMap[sp] = (speciesMap[sp] ?? 0) + 1;
  }
  res.json(Object.entries(speciesMap).map(([species, count]) => ({ species, count })));
});

router.get("/dashboard/by-drug-class", async (req, res) => {
  const rows = await db
    .select({ drugClass: drugsTable.drugClass, treatmentId: treatmentsTable.id })
    .from(treatmentsTable)
    .leftJoin(drugsTable, eq(treatmentsTable.drugId, drugsTable.id));

  const classMap: Record<string, number> = {};
  for (const r of rows) {
    const dc = r.drugClass ?? "Unknown";
    classMap[dc] = (classMap[dc] ?? 0) + 1;
  }
  res.json(Object.entries(classMap).map(([drugClass, count]) => ({ drugClass, count })));
});

router.get("/dashboard/recent-activity", async (req, res) => {
  const treatments = await db
    .select({
      id: treatmentsTable.id,
      createdAt: treatmentsTable.createdAt,
      farmName: farmsTable.name,
      animalIdentifier: animalsTable.identifier,
      drugName: drugsTable.name,
      status: treatmentsTable.status,
    })
    .from(treatmentsTable)
    .leftJoin(farmsTable, eq(treatmentsTable.farmId, farmsTable.id))
    .leftJoin(animalsTable, eq(treatmentsTable.animalId, animalsTable.id))
    .leftJoin(drugsTable, eq(treatmentsTable.drugId, drugsTable.id))
    .orderBy(sql`${treatmentsTable.createdAt} DESC`)
    .limit(5);

  const alerts = await db
    .select({
      id: alertsTable.id,
      triggeredAt: alertsTable.triggeredAt,
      farmName: farmsTable.name,
      severity: alertsTable.severity,
      message: alertsTable.message,
    })
    .from(alertsTable)
    .leftJoin(farmsTable, eq(alertsTable.farmId, farmsTable.id))
    .orderBy(sql`${alertsTable.triggeredAt} DESC`)
    .limit(5);

  const activity = [
    ...treatments.map(t => ({
      id: t.id,
      type: "treatment",
      description: `Treatment recorded: ${t.drugName ?? "Drug"} for ${t.animalIdentifier ?? "animal"} at ${t.farmName ?? "farm"}`,
      timestamp: t.createdAt.toISOString(),
      severity: "info",
      farmName: t.farmName,
    })),
    ...alerts.map(a => ({
      id: a.id + 10000,
      type: "alert",
      description: a.message,
      timestamp: a.triggeredAt.toISOString(),
      severity: a.severity,
      farmName: a.farmName,
    })),
  ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 10);

  res.json(activity);
});

export default router;
