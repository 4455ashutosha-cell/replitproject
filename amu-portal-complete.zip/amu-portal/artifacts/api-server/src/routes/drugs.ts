import { Router } from "express";
import { db } from "@workspace/db";
import { drugsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { CreateDrugBody } from "@workspace/api-zod";

const router = Router();

router.get("/drugs", async (req, res) => {
  const drugs = await db.select().from(drugsTable).orderBy(drugsTable.name);
  res.json(drugs);
});

router.post("/drugs", async (req, res) => {
  const parsed = CreateDrugBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }
  const [drug] = await db.insert(drugsTable).values(parsed.data).returning();
  res.status(201).json(drug);
});

router.get("/drugs/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [drug] = await db.select().from(drugsTable).where(eq(drugsTable.id, id));
  if (!drug) { res.status(404).json({ error: "Not found" }); return; }
  res.json(drug);
});

export default router;
