import { Router } from "express";
import { db } from "@workspace/db";
import { treatmentsTable, farmsTable, animalsTable, drugsTable, alertsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { CreateTreatmentBody, UpdateTreatmentBody } from "@workspace/api-zod";

const router = Router();

const fmt = (d: Date | null | undefined) => d ? d.toISOString() : null;

const withJoins = () =>
  db.select({
    id: treatmentsTable.id,
    farmId: treatmentsTable.farmId,
    farmName: farmsTable.name,
    animalId: treatmentsTable.animalId,
    animalIdentifier: animalsTable.identifier,
    animalSpecies: animalsTable.species,
    drugId: treatmentsTable.drugId,
    drugName: drugsTable.name,
    drugClass: drugsTable.drugClass,
    prescriptionId: treatmentsTable.prescriptionId,
    administeredBy: treatmentsTable.administeredBy,
    startDate: treatmentsTable.startDate,
    endDate: treatmentsTable.endDate,
    dosage: treatmentsTable.dosage,
    unit: treatmentsTable.unit,
    frequency: treatmentsTable.frequency,
    durationDays: treatmentsTable.durationDays,
    route: treatmentsTable.route,
    purpose: treatmentsTable.purpose,
    notes: treatmentsTable.notes,
    status: treatmentsTable.status,
    withdrawalEndDate: treatmentsTable.withdrawalEndDate,
    mrlCompliant: treatmentsTable.mrlCompliant,
    createdAt: treatmentsTable.createdAt,
  })
    .from(treatmentsTable)
    .leftJoin(farmsTable, eq(treatmentsTable.farmId, farmsTable.id))
    .leftJoin(animalsTable, eq(treatmentsTable.animalId, animalsTable.id))
    .leftJoin(drugsTable, eq(treatmentsTable.drugId, drugsTable.id));

function serializeRow(r: Awaited<ReturnType<typeof withJoins>>[0]) {
  return {
    ...r,
    startDate: fmt(r.startDate)!,
    endDate: fmt(r.endDate),
    withdrawalEndDate: fmt(r.withdrawalEndDate)!,
    createdAt: fmt(r.createdAt)!,
  };
}

router.get("/treatments", async (req, res) => {
  const rows = await withJoins().orderBy(treatmentsTable.createdAt);
  const farmId = req.query.farmId ? parseInt(req.query.farmId as string) : undefined;
  const animalId = req.query.animalId ? parseInt(req.query.animalId as string) : undefined;
  const status = req.query.status as string | undefined;
  let filtered = rows;
  if (farmId) filtered = filtered.filter(r => r.farmId === farmId);
  if (animalId) filtered = filtered.filter(r => r.animalId === animalId);
  if (status) filtered = filtered.filter(r => r.status === status);
  res.json(filtered.map(serializeRow));
});

router.post("/treatments", async (req, res) => {
  const parsed = CreateTreatmentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }
  const body = parsed.data;
  const [drug] = await db.select().from(drugsTable).where(eq(drugsTable.id, body.drugId));
  if (!drug) { res.status(400).json({ error: "Drug not found" }); return; }

  const startDate = new Date(body.startDate);
  const withdrawalEndDate = new Date(startDate);
  withdrawalEndDate.setDate(withdrawalEndDate.getDate() + body.durationDays + drug.withdrawalDays);

  const [treatment] = await db.insert(treatmentsTable).values({
    ...body,
    startDate,
    withdrawalEndDate,
    status: "active",
  }).returning();

  // Auto-generate withdrawal alert
  const daysUntilWithdrawal = Math.ceil((withdrawalEndDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
  if (daysUntilWithdrawal <= 7) {
    await db.insert(alertsTable).values({
      treatmentId: treatment.id,
      farmId: treatment.farmId,
      type: "withdrawal",
      message: `Withdrawal period ends in ${daysUntilWithdrawal} day(s) for treatment on animal group. Ensure animals are not sent for slaughter before ${withdrawalEndDate.toDateString()}.`,
      severity: daysUntilWithdrawal <= 2 ? "critical" : "warning",
      status: "open",
    });
  }

  const rows = await withJoins().where(eq(treatmentsTable.id, treatment.id));
  res.status(201).json(serializeRow(rows[0]));
});

router.get("/treatments/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const rows = await withJoins().where(eq(treatmentsTable.id, id));
  if (!rows[0]) { res.status(404).json({ error: "Not found" }); return; }
  res.json(serializeRow(rows[0]));
});

router.patch("/treatments/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const parsed = UpdateTreatmentBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid input" }); return; }
  const update: Record<string, unknown> = { ...parsed.data };
  if (parsed.data.endDate) update.endDate = new Date(parsed.data.endDate);
  await db.update(treatmentsTable).set(update).where(eq(treatmentsTable.id, id));
  const rows = await withJoins().where(eq(treatmentsTable.id, id));
  if (!rows[0]) { res.status(404).json({ error: "Not found" }); return; }
  res.json(serializeRow(rows[0]));
});

router.delete("/treatments/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(alertsTable).where(eq(alertsTable.treatmentId, id));
  await db.delete(treatmentsTable).where(eq(treatmentsTable.id, id));
  res.status(204).send();
});

export default router;
