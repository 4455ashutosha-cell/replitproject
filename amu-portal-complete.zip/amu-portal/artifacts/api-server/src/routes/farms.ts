import { Router } from "express";
import { db } from "@workspace/db";
import { farmsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { CreateFarmBody } from "@workspace/api-zod";
import { z } from "zod/v4";

const router = Router();

router.get("/farms", async (req, res) => {
  const farms = await db.select().from(farmsTable).orderBy(farmsTable.createdAt);
  res.json(farms.map(f => ({
    ...f,
    createdAt: f.createdAt.toISOString(),
  })));
});

router.post("/farms", async (req, res) => {
  const parsed = CreateFarmBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }
  const [farm] = await db.insert(farmsTable).values(parsed.data).returning();
  res.status(201).json({ ...farm, createdAt: farm.createdAt.toISOString() });
});

router.get("/farms/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const [farm] = await db.select().from(farmsTable).where(eq(farmsTable.id, id));
  if (!farm) { res.status(404).json({ error: "Not found" }); return; }
  res.json({ ...farm, createdAt: farm.createdAt.toISOString() });
});

export default router;
