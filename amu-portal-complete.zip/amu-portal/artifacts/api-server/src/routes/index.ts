import { Router, type IRouter } from "express";
import healthRouter from "./health";
import farmsRouter from "./farms";
import drugsRouter from "./drugs";
import animalsRouter from "./animals";
import prescriptionsRouter from "./prescriptions";
import treatmentsRouter from "./treatments";
import alertsRouter from "./alerts";
import dashboardRouter from "./dashboard";

const router: IRouter = Router();

router.use(healthRouter);
router.use(farmsRouter);
router.use(drugsRouter);
router.use(animalsRouter);
router.use(prescriptionsRouter);
router.use(treatmentsRouter);
router.use(alertsRouter);
router.use(dashboardRouter);

export default router;
