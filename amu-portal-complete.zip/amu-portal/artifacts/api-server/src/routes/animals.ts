import { Router } from "express";
import { db } from "@workspace/db";
import { animalsTable, farmsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { CreateAnimalBody } from "@workspace/api-zod";

const router = Router();

router.get("/animals", async (req, res) => {
  const farmId = req.query.farmId ? parseInt(req.query.farmId as string) : undefined;
  const rows = await db
    .select({
      id: animalsTable.id,
      farmId: animalsTable.farmId,
      farmName: farmsTable.name,
      species: animalsTable.species,
      breed: animalsTable.breed,
      identifier: animalsTable.identifier,
      count: animalsTable.count,
      ageMonths: animalsTable.ageMonths,
      createdAt: animalsTable.createdAt,
    })
    .from(animalsTable)
    .leftJoin(farmsTable, eq(animalsTable.farmId, farmsTable.id))
    .orderBy(animalsTable.createdAt);

  const filtered = farmId ? rows.filter(r => r.farmId === farmId) : rows;
  res.json(filtered.map(r => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.post("/animals", async (req, res) => {
  const parsed = CreateAnimalBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }
  const [animal] = await db.insert(animalsTable).values(parsed.data).returning();
  res.status(201).json({ ...animal, createdAt: animal.createdAt.toISOString() });
});

router.get("/animals/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  const rows = await db
    .select({
      id: animalsTable.id,
      farmId: animalsTable.farmId,
      farmName: farmsTable.name,
      species: animalsTable.species,
      breed: animalsTable.breed,
      identifier: animalsTable.identifier,
      count: animalsTable.count,
      ageMonths: animalsTable.ageMonths,
      createdAt: animalsTable.createdAt,
    })
    .from(animalsTable)
    .leftJoin(farmsTable, eq(animalsTable.farmId, farmsTable.id))
    .where(eq(animalsTable.id, id));
  if (!rows[0]) { res.status(404).json({ error: "Not found" }); return; }
  res.json({ ...rows[0], createdAt: rows[0].createdAt.toISOString() });
});

export default router;
