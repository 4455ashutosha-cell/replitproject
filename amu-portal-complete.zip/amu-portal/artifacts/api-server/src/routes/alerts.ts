import { Router } from "express";
import { db } from "@workspace/db";
import { alertsTable, farmsTable, treatmentsTable, animalsTable, drugsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

const fmt = (d: Date | null | undefined) => d ? d.toISOString() : null;

router.get("/alerts", async (req, res) => {
  const status = req.query.status as string | undefined;
  const farmId = req.query.farmId ? parseInt(req.query.farmId as string) : undefined;

  const rows = await db
    .select({
      id: alertsTable.id,
      treatmentId: alertsTable.treatmentId,
      farmId: alertsTable.farmId,
      farmName: farmsTable.name,
      animalIdentifier: animalsTable.identifier,
      drugName: drugsTable.name,
      type: alertsTable.type,
      message: alertsTable.message,
      severity: alertsTable.severity,
      status: alertsTable.status,
      triggeredAt: alertsTable.triggeredAt,
      resolvedAt: alertsTable.resolvedAt,
    })
    .from(alertsTable)
    .leftJoin(farmsTable, eq(alertsTable.farmId, farmsTable.id))
    .leftJoin(treatmentsTable, eq(alertsTable.treatmentId, treatmentsTable.id))
    .leftJoin(animalsTable, eq(treatmentsTable.animalId, animalsTable.id))
    .leftJoin(drugsTable, eq(treatmentsTable.drugId, drugsTable.id))
    .orderBy(alertsTable.triggeredAt);

  let filtered = rows;
  if (status) filtered = filtered.filter(r => r.status === status);
  if (farmId) filtered = filtered.filter(r => r.farmId === farmId);

  res.json(filtered.map(r => ({
    ...r,
    triggeredAt: fmt(r.triggeredAt)!,
    resolvedAt: fmt(r.resolvedAt),
  })));
});

router.patch("/alerts/:id/resolve", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.update(alertsTable).set({ status: "resolved", resolvedAt: new Date() }).where(eq(alertsTable.id, id));
  const rows = await db
    .select({
      id: alertsTable.id,
      treatmentId: alertsTable.treatmentId,
      farmId: alertsTable.farmId,
      farmName: farmsTable.name,
      animalIdentifier: animalsTable.identifier,
      drugName: drugsTable.name,
      type: alertsTable.type,
      message: alertsTable.message,
      severity: alertsTable.severity,
      status: alertsTable.status,
      triggeredAt: alertsTable.triggeredAt,
      resolvedAt: alertsTable.resolvedAt,
    })
    .from(alertsTable)
    .leftJoin(farmsTable, eq(alertsTable.farmId, farmsTable.id))
    .leftJoin(treatmentsTable, eq(alertsTable.treatmentId, treatmentsTable.id))
    .leftJoin(animalsTable, eq(treatmentsTable.animalId, animalsTable.id))
    .leftJoin(drugsTable, eq(treatmentsTable.drugId, drugsTable.id))
    .where(eq(alertsTable.id, id));
  if (!rows[0]) { res.status(404).json({ error: "Not found" }); return; }
  const r = rows[0];
  res.json({ ...r, triggeredAt: fmt(r.triggeredAt)!, resolvedAt: fmt(r.resolvedAt) });
});

export default router;
